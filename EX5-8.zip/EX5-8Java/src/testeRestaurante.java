
public class testeRestaurante {
	public static void main(String[] args) {
		
		Pedido pedido = new Pedido();
		pedido.calculaTotal();
		pedido.fazPedido();
		pedido.entregaPedido();
		
		System.out.printf("%s pediu %s no valor de R$ %s\n",
				pedido.getCliente(),pedido.getUltimoPedido(),pedido.getValorTotal());
		System.out.println("O pedido est� pendende? "+pedido.isPedidoPendente());
		
	}
}
