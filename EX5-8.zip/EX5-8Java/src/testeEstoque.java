
public class testeEstoque {
	public static void main(String[] args) {
		Produto produto = new Produto();
		produto.add();
		
		System.out.printf("Existem %s %s com valor unit�rio de R$ %s\n",
				produto.getQuantidadeAtual(),produto.getDescricao(),produto.getPrecoVenda());
		
		Venda venda = new Venda();
		venda.add();
		System.out.printf("Foi realizado uma venda de %s %s em um valor total de R$ %s\n",
				venda.getQuantidade(), produto.getDescricao(), venda.getValorVenda());
		
		
		
	}
}
