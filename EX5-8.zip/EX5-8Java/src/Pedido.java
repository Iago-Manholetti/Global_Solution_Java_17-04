
public class Pedido {
	private String cliente;
	private String ultimoPedido;
	private boolean pedidoPendente;
	private double valorTotal;

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getUltimoPedido() {
		return ultimoPedido;
	}

	public void setUltimoPedido(String ultimoPedido) {
		this.ultimoPedido = ultimoPedido;
	}

	public boolean isPedidoPendente() {
		return pedidoPendente;
	}

	public void setPedidoPendente(boolean pedidoPendente) {
		this.pedidoPendente = pedidoPendente;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	
	public void fazPedido() {
		pedidoPendente = true;
		this.cliente = "Anakin";
		this.ultimoPedido = "Moqueca de Jaca";
	}
	
	public void entregaPedido() {
		pedidoPendente = false;
	}
	
	public void calculaTotal() {
		this.valorTotal = 40;
	}
	
	
	
	
}

