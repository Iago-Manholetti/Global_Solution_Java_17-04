import java.util.Scanner;

public class Calculo {
	private double celsius;
	private double fahrenheit;
	private double resultado;
	
	
	public double getCelsius() {
		return celsius;
	}
	public void setCelsius(double celsius) {
		this.celsius = celsius;
	}
	public double getFahrenheit() {
		return fahrenheit;
	}
	public void setFahrenheit(double fahrenheit) {
		this.fahrenheit = fahrenheit;
	}
	public double getResultado() {
		return resultado;
	}
	public void setResultado(double resultado) {
		this.resultado = resultado;
	}
	
	public double calculaC() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite a temperatura em Fahrenheits ");
		double fahrenheit = scan.nextDouble();
		double celsius = (fahrenheit-32)*5/9;
		celsius = Math.round(celsius*100);
		celsius = celsius/100;
		scan.close();
		resultado = celsius;
		return resultado;
	}
	
	public double calculaF() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite a temperatura em Celsius ");
		double celsius = scan.nextDouble();
		fahrenheit = (celsius*9/5)+32;
		resultado = fahrenheit;
		scan.close();
		return resultado;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
