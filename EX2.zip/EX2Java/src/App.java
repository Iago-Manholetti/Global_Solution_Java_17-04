import java.util.Scanner;

public class App {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Calculo calculo = new Calculo();
		
		System.out.println("Digite 1 para C->F ou 2 para F>C ");
		int decisao = scan.nextInt();
		
		if (decisao==1) {
			calculo.calculaF();
			System.out.println("A temperatura em Fahrenheits � de "+calculo.getResultado()+" graus");
		}
		else if (decisao==2) {
			calculo.calculaC();
			System.out.println("A temperatura em Celsius � de "+calculo.getResultado()+" graus");
		}
		else {
			System.out.println("Valor digitado � diferente de 1 ou 2");
		}
		scan.close();
	}
}
